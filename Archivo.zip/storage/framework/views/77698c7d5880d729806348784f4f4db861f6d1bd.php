<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <div class="row">
        <div class="col-xs-12">
            <div class="page-title-box">
                <h4 class="page-title">Perfil de Usuario</h4>
                <ol class="breadcrumb p-0 m-0">
                    <li>
                        <a href="#">GeoGextion</a>
                    </li>
                    <li class="active">
                        Perfil de Usuario
                    </li>
                </ol>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
    <!-- end row -->

    <div class="row">
        <div class="col-sm-offset-2 col-sm-8">
            <div class="card-box">
                <h4 class="header-title m-t-0 m-b-20">Perfil usuario</h4>

                <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <strong><?php echo e(session('status')); ?></strong>
                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <strong><?php echo e(session('error')); ?></strong>
                    </div>
                <?php endif; ?>


                <?php echo e(Form::model(Auth::User(),['route'=>['perfil'], 'class'=>'form-horizontal', 'id'=>'actualizarusuario'])); ?>

                <div class="form-group">
                    <label class="control-label">Usuario</label>
                    <?php echo e(Form::text('name', null ,['class'=>'form-control', "required", "maxlength"=>"10", "data-parsley-pattern"=>"^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ]+(\s*[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ]*)*[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ]+$"])); ?>

                </div>

                <div class="form-group">
                    <label class="control-label">E-mail</label>
                    <?php echo e(Form::email('email', null ,['class'=>'form-control', "required"])); ?>

                </div>

                <div class="form-group">
                    <label class="control-label">Contraseña</label>
                    <?php echo e(Form::password('password',['class'=>'form-control', "maxlength"=>"12",'id'=>'password'])); ?>

                </div>
                <div class="form-group">
                    <label class="control-label">Confirmar contraseña</label>
                    <?php echo e(Form::password('password_confirmation',['class'=>'form-control',  "maxlength"=>"12", "data-parsley-equalto"=>"#password"])); ?>

                </div>
                <button type="submit" class="btn btn-success waves-effect waves-light">Guardar</button>
                <?php echo e(Form::close()); ?>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        $(function () {
            $('#actualizarusuario').parsley();
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>