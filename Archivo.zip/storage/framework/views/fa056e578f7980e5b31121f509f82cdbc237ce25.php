<div class="slimscroll-menu" id="remove-scroll">

    <!--- Sidemenu -->
    <div id="sidebar-menu">
        <!-- Left Menu Start -->
        <ul class="metisMenu nav" id="side-menu">
            <li class="menu-title">Navigation</li>

            <?php if (\Shinobi::isRole('superadmin')): ?>
            <li><a href="<?php echo e(route('listaEmpresas')); ?>"><i class="fi-help"></i><span> Crear una Empresa </span></a></li>
            <?php endif; ?>

            <?php if(Auth::user()->isRole("sadminempresa") || Auth::user()->isRole("admin") || Auth::user()->isRole("super")): ?>

                <li><a href="<?php echo e(route('home')); ?>"><i class="fi-map text-muted"></i><span> Geoposicion </span></a></li>

                <?php if (\Shinobi::isRole('sadminempresa')): ?>
                <li><a href="<?php echo e(route('listaAdministradores')); ?>"><i
                                class="fa fa-user-circle"></i><span> Administradores </span></a></li>
                <?php endif; ?>

                <?php if(Auth::user()->isRole("sadminempresa") || Auth::user()->isRole("admin") || Auth::user()->isRole("super") ): ?>
                <li>
                    <a href="javascript: void(0);" aria-expanded="true"><i class="fi-target"></i>
                        <span> Comercial </span>
                        <span class="menu-arrow"></span></a>
                    <ul class="nav-second-level nav" aria-expanded="true">

                        <?php if(Auth::user()->isRole("sadminempresa") || Auth::user()->isRole("admin")): ?>

                            <li><a href="<?php echo e(route('listasupervisores')); ?>"></i><span> Supervisores </span></a>
                            </li>
                        <?php endif; ?>
                        <li><a href="<?php echo e(route('listaacesores')); ?>"></i><span> Asesores </span></a></li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::user()->isRole("sadminempresa") || Auth::user()->isRole("admin") || Auth::user()->isRole("supert") ): ?>
                <li>
                    <a href="javascript: void(0);" aria-expanded="true"><i class="fa fa-car"></i>
                        <span> Transporte </span>
                        <span class="menu-arrow"></span></a>
                    <ul class="nav-second-level nav" aria-expanded="true">

                        <?php if(Auth::user()->isRole("sadminempresa") || Auth::user()->isRole("admin")): ?>

                            <li><a href="<?php echo e(route('listasupervisorestransporte')); ?>"></i><span> Supervisores </span></a>
                            </li>
                        <?php endif; ?>
                        <li><a href="<?php echo e(route('listatrasportador')); ?>"></i><span> Transportadores </span></a></li>
                        <li><a href="<?php echo e(route('listarvehiculo')); ?>"></i><span> Vehiculos </span></a></li>
                    </ul>
                </li>
                <?php endif; ?>

                <li><a href="<?php echo e(route('consulta')); ?>"><i class="fa fa-database"></i><span> Consulta </span></a></li>

                <?php if(Auth::user()->isRole("sadminempresa") || Auth::user()->isRole("admin")): ?>

                    <li><a href="<?php echo e(route('configuracion')); ?>"><i class="fa fa-cogs"></i><span> Configuracion empresa </span></a></li>
                <?php endif; ?>


            <?php endif; ?>


        </ul>

    </div>
    <!-- Sidebar -->
    <div class="clearfix"></div>

</div>

<!-- Sidebar -left -->