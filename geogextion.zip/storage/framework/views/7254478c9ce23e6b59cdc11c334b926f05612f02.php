<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8" />
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/logosmnormal.png')); ?>">

    <!-- C3 charts css -->
    <?php echo $__env->yieldContent('antestyles'); ?>

    <?php echo e(Html::style('plugins/sweet-alert2/sweetalert2.min.css')); ?>



    <!-- App css -->
    <?php echo e(Html::style('css/bootstrap.min.css')); ?>

    <?php echo e(Html::style('css/core.css')); ?>

    <?php echo e(Html::style('css/components.css')); ?>

    <?php echo e(Html::style('css/icons.css')); ?>

    <?php echo e(Html::style('css/menu.css')); ?>

    <?php echo e(Html::style('css/responsive.css')); ?>

    <?php echo e(Html::style('css/pages.css')); ?>

    <?php echo e(Html::script('js/modernizr.min.js')); ?>


    <?php echo $__env->yieldContent('estyles'); ?>

    <style>

        #contecarga{
            display: none;
            position: absolute;
            top:0;
            width: 98%;
            height: 100%;
            z-index: 5000;
        }

        #fondo{
            position: fixed;
            top:0;
            width: 100%;
            height: 100%;
            display: block;
            background-color: #fff;
            opacity: .5;
        }

        #imacarga{
            position: fixed;
            top:0;
            opacity: 1;
        }

        td.details-control {
            /*background: url('../images/details_open.png') no-repeat center center;*/
            color: green;
            text-align: center;
            cursor: pointer;
            width: 25px;
        }
        tr.shown td.details-control {
            color:red;
            /* background: url('../images/details_close.png') no-repeat center center;*/
        }

    </style>

</head>


<body>

<!-- Begin page -->
<div id="wrapper">

    <!-- Top Bar Start -->
    <div class="topbar">

        <!-- LOGO -->
        <div class="topbar-left">
            <!--<a href="index.html" class="logo"><span>Code<span>Fox</span></span><i class="mdi mdi-layers"></i></a>-->
            <!-- Image logo -->
            <a href="<?php echo e(route('home')); ?>" class="logo">
                        <span>
                            <img src="<?php echo e(url('images/logoblanco.png')); ?>" alt="" height="50">
                        </span>
                <i>
                    <img src="<?php echo e(url('images/logosmblanco.png')); ?>" alt="" height="38">
                </i>
            </a>
        </div>

        <!-- Button mobile view to collapse sidebar menu -->
        <div class="navbar navbar-default" role="navigation">
            <div class="container">

                <!-- Navbar-left -->
                <ul class="nav navbar-nav navbar-left nav-menu-left">
                    <li>
                        <button type="button" class="button-menu-mobile open-left waves-effect">
                            <i class="dripicons-menu"></i>
                        </button>
                    </li>

                </ul>

                <!-- Right(Notification) -->
                <ul class="nav navbar-nav navbar-right">

                    <li class="dropdown user-box">
                        <a href="" class="dropdown-toggle waves-effect user-link" data-toggle="dropdown" aria-expanded="true">
                            <img src="<?php echo e(url('images/avatar2.png')); ?>" alt="user-img" class="img-circle user-img">
                        </a>

                        <ul class="dropdown-menu dropdown-menu-right arrow-dropdown-menu arrow-menu-right user-list notify-list">
                            <li><a href="<?php echo e(route('perfil')); ?>">Perfil</a></li>
                            <li class="divider"></li>
                            <li><a href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Logout</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>

                </ul> <!-- end navbar-right -->

            </div><!-- end container -->
        </div><!-- end navbar -->
    </div>
    <!-- Top Bar End -->


    <!-- ========== Left Sidebar Start ========== -->
    <div class="left side-menu">

        <?php echo $__env->make('layouts.menulateral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;


    </div>
    <!-- Left Sidebar End -->



    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="content-page">
        <!-- Start content -->
        <div class="content">
            <div class="container">
                <?php echo $__env->yieldContent('contenido'); ?>

            </div> <!-- container -->

        </div> <!-- content -->

        <!-- Modal Bootstrap-->


        <footer class="footer text-right">
            2017 © GeoGextion. - Ceindetec.org.co
        </footer>

    </div>

    <div id='modalBs' class='modal fade' tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
            </div>
        </div>
    </div>

    <div id="contecarga">
        <div id="fondo"></div>
        <img src="<?php echo e(asset('images/62157.gif')); ?>" id="imacarga">
    </div>


    <!-- ============================================================== -->
    <!-- End Right content here -->
    <!-- ============================================================== -->


</div>
<!-- END wrapper -->



<!-- jQuery  -->
<?php echo e(Html::script('js/jquery.min.js')); ?>

<?php echo e(Html::script('js/bootstrap.min.js')); ?>

<?php echo e(Html::script('js/metisMenu.min.js')); ?>

<?php echo e(Html::script('js/waves.js')); ?>

<?php echo e(Html::script('js/jquery.slimscroll.js')); ?>


<!-- Counter js  -->
<?php echo e(Html::script('plugins/waypoints/jquery.waypoints.min.js')); ?>

<?php echo e(Html::script('plugins/counterup/jquery.counterup.min.js')); ?>

<?php echo e(Html::script('plugins/sweet-alert2/sweetalert2.min.js')); ?>


<script src="<?php echo e(asset('plugins/parsleyjs/parsley.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/parsleyjs/idioma/es.js')); ?>"></script>

<!-- App js -->
<?php echo e(Html::script('js/jquery.core.js')); ?>

<?php echo e(Html::script('js/jquery.app.js')); ?>

<?php echo e(Html::script('js/inicio.js')); ?>


<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>